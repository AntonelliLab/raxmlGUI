Example files:

Aminoacid_data.fasta
An example alignment with amino-acid data in FASTA format.


Bromeliads_DNA_data.txt
Nucleotide alignment in extended Phylip format.

Bromeliads_binary_data.txt
Binary dataset in extended Phylip format.

Note that the two Bromeliad datasets feature taxa sets that are not fully overlapping. 
When combining them in raxmlGUI to run a partitioned analysis, the non-overlapping taxa
can be either dropped or kept generating a spare matrix. 


